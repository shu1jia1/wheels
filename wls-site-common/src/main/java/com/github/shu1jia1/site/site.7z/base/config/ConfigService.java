package com.github.shu1jia1.site.base.config;

public class ConfigService {
    
}
