package com.github.shu1jia1.site.base.entity;

public interface ITokenInfo {
//	private String userId;
//	private String userName;
//	private int userType;
//	private String lang;
//	private String token;
//	private String createTime;
	
	
}
